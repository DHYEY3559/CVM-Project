from django.conf import settings
from django.shortcuts import render, redirect
from django.http import JsonResponse

from .models import Transcription
import whisper
import torch
import sounddevice as sd
from scipy.io.wavfile import write
import os
from deep_translator import GoogleTranslator
from gtts import gTTS

# Load the Whisper model
device = "cuda" if torch.cuda.is_available() else "cpu"
model = whisper.load_model("base").to(device)

def home(request):
    return render(request, 'stt_app/home.html')

def record_audio(request):
    if request.method == 'POST':
        duration = int(request.POST.get('duration', 10))
        sample_rate = 48000
        output_file = "recorded_audio.wav"

        print("Recording...")
        audio = sd.rec(int(duration * sample_rate), samplerate=sample_rate, channels=1, dtype="int16")
        sd.wait()
        write(output_file, sample_rate, audio)

        # Transcribe the audio
        transcription_text = transcribe_audio(output_file)

        # Translate the transcription
        target_language = request.POST.get('language', 'hi')  # Default to Hindi
        translated_text = translate_text(transcription_text, target_language)

        # Generate audio from the translated text
        audio_output_file = generate_audio(translated_text, target_language)

        # Save the transcription and translation to the database
        transcription = Transcription(
            transcription=transcription_text,
            translation=translated_text,
            audio_file=os.path.relpath(audio_output_file, settings.MEDIA_ROOT)  # Save relative path
        )
        transcription.save()

        # Delete the temporary audio file
        os.remove(output_file)

        return JsonResponse({
            'transcription': transcription_text,
            'translation': translated_text,
            'audio_file': os.path.join(settings.MEDIA_URL, transcription.audio_file.name)
        })

    return render(request, 'stt_app/record.html')

def transcribe_audio(file_path):
    result = model.transcribe(file_path)
    return result["text"]


def translate_text(text, target_language):
    try:
        translated = GoogleTranslator(source='auto', target=target_language).translate(text)
        return translated
    except Exception as e:
        print(f"Translation error: {e}")
        return text  # Return the original text if translation fails

def generate_audio(text, language):
    tts = gTTS(text=text, lang=language)
    audio_output_file = os.path.join(settings.MEDIA_ROOT, 'audio', f'translated_audio_{language}.mp3')
    os.makedirs(os.path.dirname(audio_output_file), exist_ok=True)  # Create the directory if it doesn't exist
    tts.save(audio_output_file)
    return audio_output_file

def results(request):
    transcriptions = Transcription.objects.all().order_by('-created_at')
    return render(request, 'stt_app/results.html', {'transcriptions': transcriptions})